# Design System Specification: The Precision Conservator

## 1. Overview & Creative North Star
The "Creative North Star" for this design system is **The Precision Conservator**. 

In high-end enterprise environments, intelligence is not just about data; it is about the curation and stewardship of that data. This system rejects the cluttered, "dashboard-heavy" aesthetics of legacy software in favor of an **Editorial Intelligence** approach. We achieve this through "Organic Brutalism"—a philosophy that combines the structural rigour of enterprise logic with the soft, atmospheric depth of a forest at dawn.

To break the "template" look, we utilize intentional asymmetry and extreme typographic scale. We move away from the rigid grid of boxes and lines, treating the interface as a living environment where information is layered through light and tone rather than separated by industrial barriers.

## 2. Colors & Environmental Tones
The palette is rooted in deep, authoritative forest greens (`primary: #00322a`) and softened by clinical, cool-grey surfaces (`surface: #f8f9ff`). 

### The "No-Line" Rule
Designers are strictly prohibited from using 1px solid borders to define sections. Traditional borders create visual noise that exhausts the user’s cognitive load. Instead, boundaries must be defined solely through background color shifts. Use `surface-container-low` to define a sidebar against a `surface` background, or a `surface-container-highest` panel to anchor a primary action area.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. We use a "Nesting" logic:
*   **Base Layer:** `surface` or `surface-dim` for the main application canvas.
*   **Secondary Layer:** `surface-container-low` for large content areas.
*   **Interaction Layer:** `surface-container-lowest` (pure white) for high-focus cards or active data tables.
*   **Emphasis Layer:** `surface-container-highest` for utility panels or persistent navigation.

### The "Glass & Gradient" Rule
To elevate the experience beyond standard flat design, use Glassmorphism for floating elements (modals, dropdowns, and floating action buttons). 
*   **Recipe:** Apply `surface-container` with 80% opacity and a `20px` backdrop-blur. 
*   **Signature Textures:** For hero sections or primary CTAs, use a subtle linear gradient from `primary` (#00322a) to `primary-container` (#004b40) at a 135-degree angle. This provides a "lustre" that feels bespoke and high-value.

## 3. Typography: The Editorial Voice
We utilize a dual-font strategy to balance character with utility.

*   **The Display Voice (Manrope):** All `display` and `headline` tokens utilize Manrope. Its geometric yet warm character provides an editorial, premium feel. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create authoritative, "magazine-style" headers that command attention.
*   **The Functional Voice (Inter):** All `title`, `body`, and `label` tokens utilize Inter. Inter is chosen for its unparalleled legibility in high-density data environments.
*   **Hierarchy Strategy:** Establish a "High-Contrast Scale." Do not be afraid to jump from a `display-md` headline directly to a `body-sm` description. This dramatic shift in scale mimics high-end print media and clarifies hierarchy better than incremental size changes.

## 4. Elevation & Depth
In this system, depth is a functional tool, not a decoration.

### The Layering Principle
Achieve lift through "Tonal Stacking." Place a `surface-container-lowest` card atop a `surface-container-low` section. The subtle shift in hex value creates a natural perception of height without the "muddiness" of shadows.

### Ambient Shadows
Shadows should only be used for elements that "float" above the logic of the page (e.g., Modals or floating Tooltips). 
*   **Value:** Use a 32px to 48px blur.
*   **Color:** Never use pure black or grey. Use the `on-surface` color (#0b1c30) at 4% to 6% opacity. This mimics ambient occlusion and feels integrated into the forest-toned palette.

### The "Ghost Border" Fallback
If a container requires a boundary for accessibility (e.g., in high-contrast modes), use a "Ghost Border." Apply the `outline-variant` token at **15% opacity**. This provides a "whisper" of a container without breaking the editorial flow.

## 5. Components

### Buttons
*   **Primary:** `primary` background with `on-primary` text. Use `DEFAULT` (8px) rounding. For a premium touch, add a 1px inner-glow (top-down) using a 10% white overlay.
*   **Secondary:** `secondary-container` background. No border.
*   **Tertiary:** Text-only using `primary` color. High-emphasis hover state using `surface-container-high`.

### Input Fields
*   **Resting State:** `surface-container-lowest` with a "Ghost Border."
*   **Focus State:** Transition the border to `primary` at 100% opacity and apply a subtle `primary-fixed` outer glow (4px blur).
*   **Labels:** Use `label-md` in `on-surface-variant`. Labels should always sit 8px above the input, never inside.

### Cards & Data Lists
*   **The Divider Ban:** Do not use horizontal lines to separate list items. Use 16px to 24px of vertical white space or alternating tonal rows (e.g., `surface` vs `surface-container-low`).
*   **Information Density:** In enterprise views, use `body-sm` for data points to maximize the "Data-to-Ink" ratio, but pair it with `title-md` for row headers to maintain readability.

### Chips & Badges
*   Use `secondary-fixed-dim` for a muted, professional appearance. 
*   Corner radius: `full` (pill shape).
*   Text: `label-sm` for maximum precision.

## 6. Do’s and Don’ts

### Do:
*   **Do** use extreme whitespace. If you think there is enough padding, add 8px more.
*   **Do** overlap elements. Having a card slightly bleed over a background transition creates a sense of intentional, layered depth.
*   **Do** use `primary-fixed` for subtle highlights in icons or small accents to draw the eye.

### Don’t:
*   **Don’t** use pure black (#000000) for text. Use `on-background` (#0b1c30) to maintain the "cool-grey" environmental tone.
*   **Don’t** use 1px solid borders for layout. If the sections aren't clear, increase the background tonal contrast between the `surface-container` tiers.
*   **Don’t** use standard "drop shadows." If an element needs to feel elevated, use tonal shifts or ultra-diffused ambient glows.